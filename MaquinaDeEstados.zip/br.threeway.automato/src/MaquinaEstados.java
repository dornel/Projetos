
import java.util.ArrayList;
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Eduardo
 */
public class MaquinaEstados {

    String entradas;
    List<Integer> contador = new ArrayList<>();
    int cont = 0;
    int saida = 0;
    String estadoAtual;
    char ent[];

    public MaquinaEstados(String entradas) {
        this.entradas = entradas;
        ent = entradas.toCharArray();
    }

    public void Inicio() {

        if (cont < ent.length) {
            if (ent[cont] == 'P') {
                cont++;
                saida++;
                contador.add(saida);
                abrir();
            } else if (ent[cont] == '.') {
                cont++;
                contador.add(saida);
                Inicio();

            }
            System.out.println(contador);

        }

    }

    public void abrir() {
        if (saida == 5) {

            parar();

        } else if (cont < ent.length) {
            if (ent[cont] == 'P') {
                cont++;
                contador.add(saida);
                parar();

            } else if (ent[cont] == '.') {
                cont++;
                saida++;
                contador.add(saida);
                abrir();

            } else if (ent[cont] == 'O') {
                cont++;
                saida--;
                contador.add(saida);
                fechar();

            }
            System.out.println(contador);

        }

    }

    public void fechar() {
        if (saida == 0) {

            parar();

        }
        if (cont < ent.length) {
            if (ent[cont] == 'P') {
                cont++;
                parar();

            } else if (ent[cont] == '.') {
                cont++;
                saida--;
                contador.add(saida);
                fechar();

            } else if (ent[cont] == 'O') {
                cont++;
                saida++;
                contador.add(saida);
                abrir();

            }

        }

    }

    public void parar() {
        if (cont < ent.length) {
            if (ent[cont] == 'P') {
                cont++;
                saida++;
                contador.add(saida);
                abrir();
            } else if (ent[cont] == '.') {
                cont++;
                contador.add(saida);
                parar();
            } else if (ent[cont] == 'O') {
                cont++;
                saida++;
                contador.add(saida);
                abrir();

            }

        }

    }

}
