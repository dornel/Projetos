

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Eduardo
 */
public class Automato {

    public static void main(String[] args) {
        
        MaquinaEstados est = new MaquinaEstados("P...O.O.P...P..");
        est.Inicio();
        
        
    }
    
}