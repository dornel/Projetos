
import com.sun.org.apache.bcel.internal.generic.AALOAD;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import sun.security.util.Length;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Eduardo
 */
public class Estados {

    String entradas;
    int cont = 0;
    int estadoAtual;
    List<Integer> contador = new ArrayList<>();
    String saida;

    public void Inicio() {

        char ent[] = entradas.toCharArray();
        for (int i = 0; i < ent.length; i++) {

            switch (ent[i]) {
                case 'P':
                    estadoAtual = 4;
                    cont++;
                    while (ent[i] != 'P') {
                        cont++;

                    }
                    contador.add(cont);
                    System.out.println("O portão está abrindo");

                    break;
                case 'O':
                    estadoAtual = 5;
                    System.out.println("Obstaculo encontrado");
                    cont--;
                    contador.add(cont);
                    break;
                case '.':
                    switch (estadoAtual) {
                        case 4:
                            cont++;
                            contador.add(cont);
                            System.out.println("O portão está abrindo");
                            break;
                        case 5:
                            
                            cont--;
                            contador.add(cont);
                            System.out.println("Obstaculo encontrado");
                            if(cont < 1){
                                estadoAtual = 0;
                            }
                            break;

                        case 0:
                            contador.add(0);
                            System.out.println("Nada mudou");
                            break;
                    }
            }

        }

        System.out.println(contador);
    }

    public Estados(String entradas) {
        this.entradas = entradas;
    }

}
